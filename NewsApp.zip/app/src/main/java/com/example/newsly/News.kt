package com.example.newsly

data class News (
    val totalResults:Int,
    val articles:List<Article>
        )
